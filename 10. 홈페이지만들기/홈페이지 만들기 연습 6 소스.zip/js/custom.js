﻿$(document).ready(function(){   


}); // document end